import './bootstrap';

import $ from 'jquery';
window.$ = window.jQuery = $;

import 'select2';
import 'select2/dist/css/select2.css';

import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';

import feather from 'feather-icons';

// import 'datatables.net-dt/css/dataTables.dataTables.min.css';
// import 'datatables.net';

import 'laravel-datatables-vite';

import Alpine from 'alpinejs';
window.Alpine = Alpine;

Alpine.start();

// import './bootstrap';

// import $ from 'jquery';
// window.$ = window.jQuery = $;

// import 'select2';
// import 'select2/dist/css/select2.css';

// import Swal from 'sweetalert2';
// import 'sweetalert2/dist/sweetalert2.min.css';

// import feather from 'feather-icons';

// import 'datatables.net-dt/css/dataTables.dataTables.min.css';
// import 'datatables.net';

// import 'laravel-datatables-vite';

// import Alpine from 'alpinejs';
// window.Alpine = Alpine;

// Alpine.start();

// $(document).ready(function () {
//     feather.replace();

//     $('.select2').select2();

//     $('#id_bahan').select2({
//         placeholder: "Cari bahan...",
//         allowClear: true
//     });


//     $('.data-table').DataTable();
// });
